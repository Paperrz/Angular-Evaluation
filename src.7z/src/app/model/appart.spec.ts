import { Appart } from './appart';

describe('Appart', () => {
  it('should create an instance', () => {
    expect(new Appart()).toBeTruthy();
  });
});
